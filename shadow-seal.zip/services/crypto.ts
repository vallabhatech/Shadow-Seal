import { PBKDF2_ITERATIONS, AES_TAG_LENGTH, SALT_LENGTH, IV_LENGTH } from '../constants';

export class CryptoService {
  
  /**
   * Generates a random salt
   */
  static generateSalt(): Uint8Array {
    return window.crypto.getRandomValues(new Uint8Array(SALT_LENGTH));
  }

  /**
   * Generates a random IV
   */
  static generateIV(): Uint8Array {
    return window.crypto.getRandomValues(new Uint8Array(IV_LENGTH));
  }

  /**
   * Derives a key from a password and salt using PBKDF2
   */
  static async deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
    const encoder = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      { name: 'PBKDF2' },
      false,
      ['deriveBits', 'deriveKey']
    );

    return window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: PBKDF2_ITERATIONS,
        hash: 'SHA-256',
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Encrypts data using AES-GCM
   */
  static async encryptData(data: ArrayBuffer, password: string): Promise<{ cipherText: ArrayBuffer; iv: Uint8Array; salt: Uint8Array }> {
    const salt = this.generateSalt();
    const iv = this.generateIV();
    const key = await this.deriveKey(password, salt);

    const cipherText = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv,
        tagLength: AES_TAG_LENGTH,
      },
      key,
      data
    );

    return { cipherText, iv, salt };
  }

  /**
   * Decrypts data using AES-GCM
   */
  static async decryptData(
    cipherText: ArrayBuffer, 
    password: string, 
    iv: Uint8Array, 
    salt: Uint8Array
  ): Promise<ArrayBuffer> {
    const key = await this.deriveKey(password, salt);

    try {
      const decrypted = await window.crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: iv,
          tagLength: AES_TAG_LENGTH,
        },
        key,
        cipherText
      );
      return decrypted;
    } catch (e) {
      throw new Error('Decryption failed. Incorrect password or tampered data.');
    }
  }

  /**
   * Helper to convert ArrayBuffer to Base64 string for storage
   */
  static arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  /**
   * Helper to convert Base64 string to Uint8Array
   */
  static base64ToUint8Array(base64: string): Uint8Array {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }
}
