const crypto = require('crypto');

// Server's master secret for HMAC signing
const SERVER_SECRET = process.env.SERVER_SECRET || 'change-this-in-production-super-secret-key';

// Generate HMAC Signature to detect tampering of stored blobs
const signData = (data) => {
  const hmac = crypto.createHmac('sha256', SERVER_SECRET);
  hmac.update(data);
  return hmac.digest('hex');
};

// Verify HMAC
const verifySignature = (data, signature) => {
  const expected = signData(data);
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
};

module.exports = { signData, verifySignature };
