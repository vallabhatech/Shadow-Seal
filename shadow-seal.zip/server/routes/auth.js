const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Log = require('../models/Log');
const { JWT_SECRET } = require('../middleware/auth');

router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 12);
    
    const user = new User({ username, password: hashedPassword });
    await user.save();

    await Log.create({ action: 'REGISTER', status: 'SUCCESS', ip: req.ip, details: `User ${username} registered` });
    
    res.status(201).json({ message: 'User registered' });
  } catch (err) {
    res.status(500).json({ message: 'Error registering user' });
  }
});

router.post('/login', async (req, res) => {
  const { username, password, deviceId } = req.body;
  
  const user = await User.findOne({ username });
  if (!user) {
    await Log.create({ action: 'LOGIN', status: 'FAILURE', ip: req.ip, deviceId, details: `User ${username} not found` });
    return res.status(400).json({ message: 'User not found' });
  }

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    await Log.create({ action: 'LOGIN', status: 'FAILURE', ip: req.ip, deviceId, details: 'Invalid password', userId: user._id });
    return res.status(400).json({ message: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: user._id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });
  
  await Log.create({ action: 'LOGIN', status: 'SUCCESS', ip: req.ip, deviceId, userId: user._id });
  res.json({ token });
});

module.exports = router;
