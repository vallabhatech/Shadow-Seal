const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const multer = require('multer');
const { GridFsStorage } = require('multer-gridfs-storage');
const crypto = require('crypto');
const path = require('path');
const { authenticateToken } = require('../middleware/auth');
const { signData } = require('../utils/crypto');
const Seal = require('../models/Seal');
const Log = require('../models/Log');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/shadowseal';

// GridFS Setup
const storage = new GridFsStorage({
  url: MONGO_URI,
  file: (req, file) => {
    return new Promise((resolve, reject) => {
      crypto.randomBytes(16, (err, buf) => {
        if (err) return reject(err);
        const filename = buf.toString('hex') + path.extname(file.originalname);
        const fileInfo = {
          filename: filename,
          bucketName: 'uploads'
        };
        resolve(fileInfo);
      });
    });
  }
});

const upload = multer({ storage });

// Connect GridFS
let gfs;
mongoose.connection.once('open', () => {
  gfs = new mongoose.mongo.GridFSBucket(mongoose.connection.db, {
    bucketName: 'uploads'
  });
});

// POST /api/encrypt - Upload encrypted blob
router.post('/encrypt', authenticateToken, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file uploaded' });

  const { iv, salt, originalName } = req.body;
  
  // In a real stream, we would calculate signature during stream. 
  // For simplicity here, we sign the filename + iv + salt as a metadata integrity check
  const signature = signData(`${req.file.filename}:${iv}:${salt}`);

  const seal = new Seal({
    filename: originalName,
    storedFilename: req.file.filename,
    ownerId: req.user.id,
    iv,
    salt,
    signature,
    size: req.file.size
  });

  await seal.save();
  await Log.create({ 
    action: 'ENCRYPT', 
    status: 'SUCCESS', 
    userId: req.user.id, 
    ip: req.ip, 
    details: `Sealed ${originalName}` 
  });

  res.json({ message: 'File sealed successfully', id: seal._id });
});

// GET /api/logs - Get User Logs
router.get('/logs', authenticateToken, async (req, res) => {
  const logs = await Log.find({ userId: req.user.id }).sort({ timestamp: -1 }).limit(50);
  res.json(logs);
});

module.exports = router;
