const mongoose = require('mongoose');

const SealSchema = new mongoose.Schema({
  filename: { type: String, required: true },
  storedFilename: { type: String, required: true }, // GridFS filename
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  iv: { type: String, required: true }, // Base64
  salt: { type: String, required: true }, // Base64
  signature: { type: String, required: true }, // Server-side HMAC
  createdAt: { type: Date, default: Date.now },
  size: { type: Number }
});

module.exports = mongoose.model('Seal', SealSchema);
