const mongoose = require('mongoose');

const LogSchema = new mongoose.Schema({
  timestamp: { type: Date, default: Date.now },
  action: { type: String, enum: ['ENCRYPT', 'DECRYPT', 'LOGIN', 'REGISTER', 'TAMPER_DETECTED'], required: true },
  status: { type: String, enum: ['SUCCESS', 'FAILURE'], required: true },
  ip: String,
  deviceId: String, // Fingerprint from client
  details: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  anomalyLevel: { type: String, enum: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'], default: 'LOW' }
});

module.exports = mongoose.model('Log', LogSchema);
